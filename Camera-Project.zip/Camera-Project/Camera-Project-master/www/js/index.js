/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('devicego', this.ondevicego.bind(this), false);
    },



    // devicego Event Handler
    //
   
    ondevicego: function() {
        this.receivedEvent('devicego');
		document.getElementById('Camera').addEventListener('click',Camera,false);
		document.getElementById('Gallery').addEventListener('click',Gallery,false);
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listenElement = parentElement.querySelector('.listen');
        var receivedElement = parentElement.querySelector('.received');


        
        listenElement.setAttribute('style', 'display:none;');
        
        receivedElement.setAttribute('style', 'display:block;');



        console.log('Received Event: ' + id);
    }
};

function setOptions(srcType) {
    var option = {
    
        quality: 50,
        destinationType: Camera.DestinationType.FILE_URI,
        // In this app, dynamically set the picture source, Camera or photo gallery
      
        sourceType: srcType,
      
        encodingType: Camera.EncodingType.JPEG,
      
        mediaType: Camera.MediaType.PICTURE,
      
        allowEdit: true,
      
        correctOrientation: true  
    }
    return option;
}

function Camera(){
        //opens the device's default camera application so that the user can take a picture
        navigator.camera.getPicture(function cameraSuccess(imageUri) {
        //Function to display the image
        displayImage(imageUri);

    }
    , function cameraError(error) {
        console.debug("Unable to obtain picture: " + error, "app");

    }
    , {quality: 50, destinationType: Camera.DestinationType.FILE_URI});

}

function displayImage(imgUri) {

    //Set the source of the image element as the image URI
    var elem = document.getElementById('imgFile');
    elem.src = imgUri;
}

//To open the image gallery of the device
function Gallery()
{
    //Put the source of the images to "SAVEDPHOTOALBUM"
    var srcType = Camera.PictureSourceType.SAVEDPHOTOALBUM;
    var option = setOptions(srcType);
    //Create a new entry
     var func = createNewFileEntry;

    navigator.camera.getPicture(function cameraSuccess(imageUri) {

        displayImage(imageUri);

        //Check for Error
    }, function cameraError(error) {
        console.debug("Unable to obtain picture: " + error, "app");

    }, option);
}

function createNewFileEntry(imgUri) {
    window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function success(dirEntry) {

        
        dirEntry.getFile("tempFile.jpeg", { create: true, exclusive: false }, function (fileEntry) {

            // Write to the file
            writeFile(fileEntry, imgUri);
            console.log("got file: " + fileEntry.fullPath);
            displayFileData(fileEntry.fullPath, "File copied to");

        }, onErrorCreateFile);

    }, onErrorResolveUrl);
}

app.initialize();